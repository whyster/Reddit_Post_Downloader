Fill in count textbox with the number of posts you want to copy
Fill in the subreddit textbox with the subreddit name [e.g. if you wanted to scrape r/copypasta you'd type in copypasta]
Fill in the save location textbox with the name of the file you want to save

If it looks stuck dont worry, so long as your file's size is increasing then its working.